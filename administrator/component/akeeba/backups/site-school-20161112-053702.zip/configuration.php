<?php
define('HOST', 'localhost');
define('USER', 'remote');
define('PASS', 'eSTaTiGa');
define('DB', 'school');

?>