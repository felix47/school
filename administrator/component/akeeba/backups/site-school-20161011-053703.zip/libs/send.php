<?php
if((isset($_POST['name'])&&$_POST['name']!="")){ //Проверка отправилось ли наше поля name и не пустые ли они
        $to = 'admin@ekaterinahotel.com'; //Почта получателя, через запятую можно указать сколько угодно адресов
        $subject = 'Заказ столика'; //Загаловок сообщения
        $message = '
                <html>
                    <head>
                        <title>'.$subject.'</title>
                    </head>
                    <body>
                        <p>Имя: '.$_POST['name'].'</p>
                        <p>Email: '.$_POST['email'].'</p>
                    </body>
                </html>'; //Текст нащего сообщения можно использовать HTML теги
        $headers  = "Content-type: text/html; charset=utf-8 \r\n"; //Кодировка письма
        $headers .= "From: Заказ столика с сайта <info@shtaken.ru>\r\n"; //Наименование и почта отправителя
        mail($to, $subject, $message, $headers); //Отправка письма с помощью функции mail
}
?>