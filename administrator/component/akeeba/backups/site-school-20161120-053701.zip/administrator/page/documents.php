<?php
function content_documents($db){

    if($_REQUEST['area'] = 'list'){
        echo '1';
    }

    // header("Location: /administrator/");

}
?>